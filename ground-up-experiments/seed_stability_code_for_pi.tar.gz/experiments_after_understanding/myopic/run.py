"""True myopic baseline on ThreeGeneration (3-gene).

Myopic policy at state s:
    Q_myopic(s, i) = r_test(i, s) + Σ_g P(g|s,i) · V_stop(s')
                     ↑ immediate     ↑ expected stopping value after test result

Picks argmax_i Q_myopic. Stops if max Q_myopic <= V_stop(s).
True value L is computed by recursive rollout (not approximated).
"""
from __future__ import annotations

import json
import pickle
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np

HERE        = Path(__file__).resolve().parent
ROOT        = HERE.parent.parent
EXPERIMENTS = ROOT / "ground-up-experiments"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(EXPERIMENTS))

from genetic_dp.exact_dp.utils  import GENOTYPE_STATES, lift_tuple_posteriors_to_genes
from genetic_dp.models.belief   import InferenceResult
from genetic_dp.models.reward   import r_reward, r_reward_test

CACHE_DIR = EXPERIMENTS / "step9_gnn_3gene" / "results" / "cache"

ALLELE_REGIMES = ["LowHigh", "MediumEven", "LowLow", "HighHigh", "MixedA", "MixedB"]
TEST_KEYS = [
    f"ThreeGeneration_{reg}_{pre}_3gene"
    for reg in ALLELE_REGIMES
    for pre in ["Base", "Aggressive"]
]


# ── helpers ────────────────────────────────────────────────────────────────────

def _marg(entry):
    return entry.marginals if isinstance(entry, InferenceResult) else entry

def _per_gene(entry, genes):
    if isinstance(entry, InferenceResult):
        return entry.get_per_gene_probs()
    return lift_tuple_posteriors_to_genes(entry, genes, GENOTYPE_STATES)

def _tuple_pmf(entry, person):
    if isinstance(entry, InferenceResult):
        return entry.get_tuple_pmfs().get(person, {})
    return entry[person]


def compute_v_stop(state, ds) -> float:
    entry       = ds["belief"][state]
    marg        = _marg(entry)
    config      = ds["config"]
    individuals = ds["individuals"]
    genes       = ds.get("genes")
    tested      = {i for i, _ in state}
    if genes:
        pg = _per_gene(entry, genes)
        return float(sum(
            r_reward(k, marg, config.a, config.b, config.c, config.delta,
                     per_gene_probs=pg,
                     a_gene=config.a_gene, b_gene=config.b_gene,
                     c_gene=config.c_gene, delta_gene=config.delta_gene)
            for k in individuals if k not in tested
        ))
    return float(sum(
        r_reward(k, marg, config.a, config.b, config.c, config.delta)
        for k in individuals if k not in tested
    ))


def compute_r_test(i, state, ds) -> float:
    entry  = ds["belief"][state]
    marg   = _marg(entry)
    config = ds["config"]
    genes  = ds.get("genes")
    if genes:
        pg = _per_gene(entry, genes)
        return float(r_reward_test(
            i, marg, config.a, config.b, config.c, config.delta,
            config.fixed_cost, config.variable_cost,
            per_gene_probs=pg,
            a_gene=config.a_gene, c_gene=config.c_gene, delta_gene=config.delta_gene,
        ))
    return float(r_reward_test(
        i, marg, config.a, config.b, config.c, config.delta,
        config.fixed_cost, config.variable_cost,
    ))


# ── myopic rollout ─────────────────────────────────────────────────────────────

def myopic_policy_value(ds, log=print) -> float:
    """
    True myopic policy:
        Q_myopic(s, i) = r_test(i,s) + Σ_g P(g|s,i) · V_stop(s')

    Picks argmax Q_myopic. Stops if max Q_myopic <= V_stop(s).
    Returns the TRUE expected value of following this policy from root.
    """
    belief      = ds["belief"]
    individuals = ds["individuals"]

    v_stop_cache = {}
    def cached_v_stop(state):
        if state not in v_stop_cache:
            v_stop_cache[state] = compute_v_stop(state, ds)
        return v_stop_cache[state]

    memo = {}

    def value_at(state) -> float:
        if state in memo:
            return memo[state]

        tested   = {i for i, _ in state}
        v_stop   = cached_v_stop(state)

        if len(tested) == len(individuals):
            memo[state] = 0.0
            return 0.0

        entry  = belief[state]
        best_q = v_stop
        best_i = None

        for i in individuals:
            if i in tested:
                continue
            r_i   = compute_r_test(i, state, ds)
            pmf_i = _tuple_pmf(entry, i)

            # one-step lookahead to V_stop(s') — true myopic
            exp_v_stop = 0.0
            for g, prob_g in pmf_i.items():
                if prob_g <= 1e-12:
                    continue
                next_s = frozenset(state | {(i, g)})
                if next_s in belief:
                    exp_v_stop += prob_g * cached_v_stop(next_s)

            q_i = r_i + exp_v_stop
            if q_i > best_q:
                best_q = q_i
                best_i = i

        if best_i is None:
            memo[state] = v_stop
            return v_stop

        # true value: follow myopic choice, recurse with true future
        r_best   = compute_r_test(best_i, state, ds)
        pmf_best = _tuple_pmf(entry, best_i)
        exp_true = 0.0
        for g, prob_g in pmf_best.items():
            if prob_g <= 1e-12:
                continue
            next_s = frozenset(state | {(best_i, g)})
            if next_s not in belief:
                continue
            exp_true += prob_g * value_at(next_s)

        result      = r_best + exp_true
        memo[state] = result
        return result

    return value_at(frozenset())


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    results_dir = HERE / "results"
    results_dir.mkdir(exist_ok=True)

    log_f = open(results_dir / "run.log", "a")
    def log(msg=""):
        print(msg, flush=True)
        log_f.write(msg + "\n")
        log_f.flush()

    log(f"\n{'='*60}")
    log(f"[MYOPIC] {datetime.now().isoformat()}")
    log(f"policy: Q_myopic(s,i) = r_test(i,s) + Σ_g P(g|s,i)·V_stop(s')")
    log(f"configs: {len(TEST_KEYS)}")

    results = {}
    out = results_dir / "results.json"
    if out.exists():
        results = json.loads(out.read_text())
        if results:
            log(f"Resuming — already have {len(results)} configs")

    for key in TEST_KEYS:
        if key in results:
            log(f"  SKIP {key} — already done")
            continue

        log(f"\n{'─'*50}")
        log(f"[CONFIG] {key}")
        t0 = time.time()

        with open(CACHE_DIR / f"{key}.pkl", "rb") as f:
            ds = pickle.load(f)

        V_root      = ds["V_root"]
        V_stop_root = ds["V_stop_root"]
        log(f"  V*(root)={V_root:.6f}  V_stop(root)={V_stop_root:.6f}")

        L      = myopic_policy_value(ds, log=log)
        denom  = V_root - V_stop_root
        ratio2 = (V_root - L) / denom if abs(denom) > 1e-12 else 0.0

        log(f"  L(myopic)={L:.6f}  ratio2={ratio2:.6f}  ({time.time()-t0:.0f}s)")
        results[key] = {"ratio2": float(ratio2), "L": float(L), "V_root": float(V_root)}
        out.write_text(json.dumps(results, indent=2))

    avg = float(np.mean([r["ratio2"] for r in results.values()])) if results else float("nan")
    log(f"\n{'='*60}")
    log(f"MYOPIC avg ratio2 = {avg:.4f}  ({len(results)}/{len(TEST_KEYS)} configs)")
    log_f.close()


if __name__ == "__main__":
    main()
