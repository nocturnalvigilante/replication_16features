"""True myopic baseline for 2-gene ThreeGeneration.

Q_myopic(s, i) = r_test(i, s) + Σ_g P(g|s,i) · V_stop(s')
Same data generation as two_gene/run.py.
"""
from __future__ import annotations

import json
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np

HERE        = Path(__file__).resolve().parent
ROOT        = HERE.parent.parent
EXPERIMENTS = ROOT / "ground-up-experiments"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(EXPERIMENTS))

from shared.data_gen import build_two_gene_dataset
from genetic_dp.exact_dp.utils  import GENOTYPE_STATES, lift_tuple_posteriors_to_genes
from genetic_dp.models.belief   import InferenceResult
from genetic_dp.models.reward   import r_reward, r_reward_test

GENES = ("GeneA", "GeneB")

ALLELE_FREQ_REGIMES = {
    "LowHigh":    {"GeneA": 0.02, "GeneB": 0.15},
    "MediumEven": {"GeneA": 0.08, "GeneB": 0.08},
    "LowLow":     {"GeneA": 0.02, "GeneB": 0.02},
    "HighHigh":   {"GeneA": 0.15, "GeneB": 0.15},
    "MixedA":     {"GeneA": 0.02, "GeneB": 0.10},
    "MixedB":     {"GeneA": 0.05, "GeneB": 0.12},
}

TEST_CONFIGS = [
    ("ThreeGeneration", reg, pre)
    for reg in ALLELE_FREQ_REGIMES
    for pre in ["Base", "Aggressive"]
]


def _marg(entry):
    return entry.marginals if isinstance(entry, InferenceResult) else entry

def _per_gene(entry):
    if isinstance(entry, InferenceResult):
        return entry.get_per_gene_probs()
    return lift_tuple_posteriors_to_genes(entry, GENES, GENOTYPE_STATES)

def _tuple_pmf(entry, person):
    if isinstance(entry, InferenceResult):
        return entry.get_tuple_pmfs().get(person, {})
    return entry[person]


def compute_v_stop(state, ds):
    entry   = ds["belief"][state]
    marg    = _marg(entry)
    pg      = _per_gene(entry)
    config  = ds["config"]
    tested  = {p for p, _ in state}
    return float(sum(
        r_reward(k, marg, config.a, config.b, config.c, config.delta,
                 per_gene_probs=pg, a_gene=config.a_gene, b_gene=config.b_gene,
                 c_gene=config.c_gene, delta_gene=config.delta_gene)
        for k in ds["individuals"] if k not in tested
    ))


def compute_r_test(person, state, ds):
    entry  = ds["belief"][state]
    marg   = _marg(entry)
    pg     = _per_gene(entry)
    config = ds["config"]
    return float(r_reward_test(
        person, marg, config.a, config.b, config.c, config.delta,
        config.fixed_cost, config.variable_cost,
        per_gene_probs=pg, a_gene=config.a_gene,
        c_gene=config.c_gene, delta_gene=config.delta_gene,
    ))


def myopic_policy_value(ds, log=print):
    belief      = ds["belief"]
    individuals = ds["individuals"]

    v_stop_cache = {}
    def cached_v_stop(state):
        if state not in v_stop_cache:
            v_stop_cache[state] = compute_v_stop(state, ds)
        return v_stop_cache[state]

    memo = {}

    def value_at(state):
        if state in memo:
            return memo[state]
        tested   = {p for p, _ in state}
        v_stop   = cached_v_stop(state)

        if len(tested) == len(individuals):
            memo[state] = 0.0
            return 0.0

        entry  = belief[state]
        best_q = v_stop
        best_i = None

        for i in individuals:
            if i in tested:
                continue
            r_i   = compute_r_test(i, state, ds)
            pmf_i = _tuple_pmf(entry, i)
            exp_v_stop = sum(
                prob * cached_v_stop(frozenset(state | {(i, g)}))
                for g, prob in pmf_i.items()
                if prob > 1e-12 and frozenset(state | {(i, g)}) in belief
            )
            q_i = r_i + exp_v_stop
            if q_i > best_q:
                best_q = q_i
                best_i = i

        if best_i is None:
            memo[state] = v_stop
            return v_stop

        pmf_best = _tuple_pmf(entry, best_i)
        exp_true = sum(
            prob * value_at(frozenset(state | {(best_i, g)}))
            for g, prob in pmf_best.items()
            if prob > 1e-12 and frozenset(state | {(best_i, g)}) in belief
        )
        result = compute_r_test(best_i, state, ds) + exp_true
        memo[state] = result
        return result

    L      = value_at(frozenset())
    V_root = ds["V_root"]
    V_stop = ds["V_stop_root"]
    denom  = V_root - V_stop
    ratio2 = (V_root - L) / denom if abs(denom) > 1e-12 else 0.0
    return float(ratio2), float(L)


def main():
    results_dir = HERE / "results"
    results_dir.mkdir(exist_ok=True)

    log_f = open(results_dir / "myopic.log", "a")
    def log(msg=""):
        print(msg, flush=True)
        log_f.write(msg + "\n")
        log_f.flush()

    log(f"\n{'='*60}")
    log(f"[MYOPIC 2-GENE] {datetime.now().isoformat()}")
    log(f"policy: Q_myopic(s,i) = r_test(i,s) + Σ_g P(g|s,i)·V_stop(s')")

    results = {}
    out = results_dir / "myopic_results.json"
    if out.exists():
        results = json.loads(out.read_text())
        if results:
            log(f"Resuming — already have {len(results)} configs")

    for fam, reg, pre in TEST_CONFIGS:
        key = f"{fam}_{reg}_{pre}_2gene"
        if key in results:
            log(f"  SKIP {key}")
            continue

        log(f"\n{'─'*50}")
        log(f"[CONFIG] {key}")
        t0 = time.time()

        ds = build_two_gene_dataset(
            family_label=fam,
            allele_freqs=ALLELE_FREQ_REGIMES[reg],
            preset_label=pre,
            genes=GENES,
        )
        log(f"  states={len(ds['states'])}  V*(root)={ds['V_root']:.4f}  V_stop(root)={ds['V_stop_root']:.4f}")

        ratio2, L = myopic_policy_value(ds, log=log)
        log(f"  ratio2={ratio2:.4f}  L={L:.4f}  ({time.time()-t0:.0f}s)")
        results[key] = {"ratio2": ratio2, "L": L, "V_root": ds["V_root"]}
        out.write_text(json.dumps(results, indent=2))

    avg = np.mean([r["ratio2"] for r in results.values()]) if results else float("nan")
    log(f"\n{'='*60}")
    log(f"MYOPIC 2-gene avg ratio2 = {avg:.4f}")
    log_f.close()


if __name__ == "__main__":
    main()
