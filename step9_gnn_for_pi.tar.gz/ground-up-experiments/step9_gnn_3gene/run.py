"""Step 9 — Training: GNN over 3-gene pedigrees (multi-topology).

Trains on 3 family structures × 6 allele regimes × 2 presets = 36 configs,
holding out 2 per family for testing.

Node features (10 per person):
    [P(g=0)_GeneA .. P(g=2)_GeneC, is_tested]

Handles variable N (3/4/5 nodes) — GNN uses mean pooling so N can vary.
Each epoch interleaves batches from all topology groups.

Run:
    python step9_gnn_3gene/run.py --device cuda --epochs 500
"""
from __future__ import annotations

import pickle
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

HERE         = Path(__file__).resolve().parent
EXPERIMENTS  = HERE.parent
PROJECT_ROOT = EXPERIMENTS.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(EXPERIMENTS))

from shared.model   import PedigreeGNN
from shared.data_gen import FAMILY_CASES
from genetic_dp.utils.pedigree_generator import generate_deterministic_pedigree

GENES         = ("GeneA", "GeneB", "GeneC")
NODE_FEAT_DIM = 3 * len(GENES) + 1   # 10
CACHE_DIR     = HERE / "results" / "cache"

FAMILIES = ["Trio", "Nuclear", "ThreeGeneration"]

ALLELE_REGIMES = [
    "LowHigh", "MediumEven", "LowLow", "HighHigh", "MixedA", "MixedB",
]

# Hold out 2 configs per family (1 regime × Aggressive preset each)
TEST_KEYS = {
    "ThreeGeneration_MediumEven_Aggressive_3gene",
    "ThreeGeneration_HighHigh_Aggressive_3gene",
    "Nuclear_MediumEven_Aggressive_3gene",
    "Nuclear_HighHigh_Aggressive_3gene",
    "Trio_MediumEven_Aggressive_3gene",
    "Trio_HighHigh_Aggressive_3gene",
}

ALL_KEYS = [
    f"{family}_{regime}_{preset}_3gene"
    for family in FAMILIES
    for regime  in ALLELE_REGIMES
    for preset  in ["Base", "Aggressive"]
]

TRAIN_KEYS = [k for k in ALL_KEYS if k not in TEST_KEYS]


# ─── helpers ─────────────────────────────────────────────────────────────────

def build_edge_index(family_label: str, individuals: list) -> np.ndarray:
    pedigree = generate_deterministic_pedigree(FAMILY_CASES[family_label])
    idx = {p: i for i, p in enumerate(individuals)}
    srcs, dsts = [], []
    for child in pedigree.get_offspring():
        for parent in pedigree.get_parents(child):
            if parent in idx and child in idx:
                srcs.append(idx[parent])
                dsts.append(idx[child])
    return np.array([srcs, dsts], dtype=np.int64) if srcs else np.zeros((2, 0), dtype=np.int64)


def extract_node_features(ds: dict, individuals: list) -> np.ndarray:
    """Fast: reshape pre-built X + add tested flag. Returns (N, n_people, 10)."""
    X      = ds["X"]
    states = ds["states"]
    n_gene_feats = 3 * len(ds.get("genes", GENES))
    n_people     = len(individuals)
    person_idx   = {p: i for i, p in enumerate(individuals)}
    N   = len(states)
    nf  = X.reshape(N, n_people, n_gene_feats).copy()
    col = np.zeros((N, n_people, 1), dtype=np.float32)
    for i, state in enumerate(states):
        for person, _ in state:
            col[i, person_idx[person], 0] = 1.0
    return np.concatenate([nf, col], axis=-1)   # (N, n_people, 10)


# ─── multi-topology training ──────────────────────────────────────────────────

def train_gnn(groups: list[dict], model: PedigreeGNN,
              epochs: int = 500, start_epoch: int = 1,
              lr: float = 1e-3, val_frac: float = 0.2,
              batch_size: int = 512, device: str = "cpu",
              print_every: int = 50, ckpt_path=None, ckpt_every: int = 50,
              history=None) -> tuple[PedigreeGNN, dict]:
    """
    Train on multiple topology groups simultaneously.

    groups: list of dicts, each with:
        "nf"  : (N, n_people_i, 10) GPU tensor
        "y"   : (N,) GPU tensor
        "ei"  : (2, E_i) GPU tensor
        "key" : str label
    """
    model     = model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss()
    if history is None:
        history = {"train_loss": [], "val_loss": []}

    # Split each group into train / val using contiguous slices (views, no GPU copy)
    train_groups, val_groups = [], []
    for g in groups:
        N   = g["nf"].shape[0]
        n_v = max(1, int(N * val_frac))
        n_t = N - n_v
        train_groups.append({"nf": g["nf"][:n_t], "y": g["y"][:n_t], "ei": g["ei"]})
        val_groups.append(  {"nf": g["nf"][n_t:], "y": g["y"][n_t:], "ei": g["ei"]})

    n_train = sum(g["nf"].shape[0] for g in train_groups)
    n_val   = sum(g["nf"].shape[0] for g in val_groups)

    for epoch in range(start_epoch, epochs + 1):
        model.train()
        train_loss = 0.0

        for g in train_groups:
            M    = g["nf"].shape[0]
            perm = torch.randperm(M, device=device)
            for start in range(0, M, batch_size):
                sl = perm[start: start + batch_size]
                optimizer.zero_grad()
                loss = criterion(model.forward_batch(g["nf"][sl], g["ei"]), g["y"][sl])
                loss.backward()
                optimizer.step()
                train_loss += loss.item() * len(sl)
        train_loss /= n_train

        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for g in val_groups:
                M = g["nf"].shape[0]
                for start in range(0, M, batch_size):
                    end = min(start + batch_size, M)
                    val_loss += criterion(
                        model.forward_batch(g["nf"][start:end], g["ei"]), g["y"][start:end]
                    ).item() * (end - start)
        val_loss /= n_val

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)

        if epoch % print_every == 0:
            print(f"  epoch {epoch:4d}/{epochs}  train={train_loss:.6f}  val={val_loss:.6f}", flush=True)

        if ckpt_path is not None and epoch % ckpt_every == 0:
            tmp = Path(str(ckpt_path) + ".tmp")
            torch.save({"epoch": epoch, "model_state": model.state_dict(), "history": history}, tmp)
            tmp.replace(Path(ckpt_path))

    return model, history


# ─── main ────────────────────────────────────────────────────────────────────

def main(device: str = "cpu", target_epochs: int = 500, fresh: bool = False):
    results_dir = HERE / "results"
    ckpt_path   = results_dir / "gnn3_ckpt.pt"
    results_dir.mkdir(exist_ok=True)

    log_f = open(results_dir / "train.log", "a")
    log_f.write(f"\n{'='*60}\n[TRAIN] {datetime.now().isoformat()}\n{'='*60}\n")
    def log(msg=""):
        print(msg, flush=True); log_f.write(msg + "\n"); log_f.flush()

    log(f"node_feat_dim={NODE_FEAT_DIM}  device={device}  epochs={target_epochs}")
    log(f"train configs: {len(TRAIN_KEYS)}  test configs: {len(TEST_KEYS)}")

    # ── 1. Verify all train pkls exist ────────────────────────────────────────
    log("\n[1] Cache check (train configs):")
    for key in TRAIN_KEYS:
        pkl = CACHE_DIR / f"{key}.pkl"
        if not pkl.exists():
            raise FileNotFoundError(f"Missing: {pkl}\nRun build_datasets.py first.")
        log(f"    {key}  [OK]")

    # ── 2. Load training data, group by family (topology) ────────────────────
    log("\n[2] Loading training data:")
    family_groups: dict[str, dict] = {}   # family → {nf_parts, y_parts, ei, individuals}

    for key in TRAIN_KEYS:
        family = key.split("_")[0]   # e.g. "ThreeGeneration"
        t0 = time.time()
        with open(CACHE_DIR / f"{key}.pkl", "rb") as f:
            ds = pickle.load(f)

        individuals = ds["individuals"]

        if family not in family_groups:
            ei = build_edge_index(family, individuals)
            family_groups[family] = {
                "nf_parts": [], "y_parts": [],
                "ei": ei, "individuals": individuals,
            }

        nf = extract_node_features(ds, individuals)
        family_groups[family]["nf_parts"].append(nf)
        family_groups[family]["y_parts"].append(ds["Y"])
        log(f"    {key}: {len(ds['states']):,} states  ({time.time()-t0:.1f}s)")
        del ds

    # Concatenate within each family, move to device
    groups = []
    for family, g in family_groups.items():
        nf_all = np.concatenate(g["nf_parts"], axis=0)
        y_all  = np.concatenate(g["y_parts"],  axis=0)
        groups.append({
            "key": family,
            "nf":  torch.FloatTensor(nf_all).to(device),
            "y":   torch.FloatTensor(y_all).to(device),
            "ei":  torch.LongTensor(g["ei"]).to(device),
        })
        log(f"    [{family}] total: {len(y_all):,} samples  nf={nf_all.shape}")
        del nf_all, y_all

    total_train = sum(g["nf"].shape[0] for g in groups)
    log(f"    Grand total: {total_train:,} training samples across {len(groups)} topologies")

    # ── 3. Train ──────────────────────────────────────────────────────────────
    log(f"\n[3] Training GNN:")
    model = PedigreeGNN(node_feat_dim=NODE_FEAT_DIM, hidden_dim=32, n_rounds=2)

    start_epoch = 1
    history     = {"train_loss": [], "val_loss": []}
    if not fresh and ckpt_path.exists():
        ckpt        = torch.load(ckpt_path, map_location=device)
        start_epoch = ckpt["epoch"] + 1
        model.load_state_dict(ckpt["model_state"])
        history     = ckpt.get("history", history)
        log(f"    Resumed from checkpoint epoch {ckpt['epoch']}/{target_epochs}")
    else:
        log(f"    Starting fresh (0/{target_epochs})")

    if start_epoch <= target_epochs:
        t0 = time.time()
        model, history = train_gnn(
            groups, model,
            epochs=target_epochs, start_epoch=start_epoch,
            lr=1e-3, batch_size=512, device=device,
            print_every=50, ckpt_path=ckpt_path, ckpt_every=50,
            history=history,
        )
        log(f"    Done in {time.time()-t0:.1f}s")
    else:
        log(f"    Already at {start_epoch-1}/{target_epochs} — skipping.")

    torch.save(model.state_dict(), results_dir / "gnn3_model.pt")
    log(f"\n[DONE] model saved → gnn3_model.pt")
    log(f"       train_loss={history['train_loss'][-1]:.6f}  val_loss={history['val_loss'][-1]:.6f}")
    log("Run eval.py next.")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--device", default="cpu")
    p.add_argument("--epochs", type=int, default=500)
    p.add_argument("--fresh",  action="store_true")
    args = p.parse_args()
    main(device=args.device, target_epochs=args.epochs, fresh=args.fresh)
